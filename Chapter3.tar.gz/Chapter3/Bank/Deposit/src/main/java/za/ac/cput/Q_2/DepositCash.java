package za.ac.cput.Q_2;

/**
 * Created by student on 2015/02/20.
 */
public interface DepositCash {

    float depositMoney(float balance, float amount );
}
