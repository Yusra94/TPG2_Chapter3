package za.ac.cput.Q_2;

/**
 * Created by student on 2015/02/20.
 */
public interface WithdrawCash {

    float WithdrawMoney(float balance, float amount );
}
