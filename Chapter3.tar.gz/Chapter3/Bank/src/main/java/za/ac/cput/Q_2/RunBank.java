package za.ac.cput.Q_2;

/**
 * Created by student on 2015/02/20.
 */
public interface RunBank {

    float depositMoney(float balance, float amount );
    float WithdrawMoney(float balance, float amount );
}
